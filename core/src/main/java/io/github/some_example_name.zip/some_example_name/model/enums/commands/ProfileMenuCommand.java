package io.github.some_example_name.model.enums.commands;

public enum ProfileMenuCommand implements Command {
    LOGOUT("^user\\s+logout\\s*$"),
    CHANGE_USERNAME("^change\\s+username\\s+-u\\s+(?<username>\\S+)\\s*$"),
    CHANGE_NICKNAME("^change\\s+nickname\\s+-n\\s+(?<nickname>\\S+)\\s*$"),
    CHANGE_EMAIL("^change\\s+email\\s+-e\\s+(?<email>\\S+)\\s*$"),
    CHANGE_PASSWORD("^change\\s+password\\s+-p\\s+(?<newPassword>\\S+)\\s+-o\\s+(?<oldPassword>\\S+)\\s*$"),
    SHOW_INFO("^user\\s+info\\s*$");

    private final String pattern;

    ProfileMenuCommand(String pattern) {
        this.pattern = pattern;
    }

    @Override
    public String getPattern() {
        return pattern;
    }
}
