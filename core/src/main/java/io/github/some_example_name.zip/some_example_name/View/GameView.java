package io.github.some_example_name.View;

import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.GL20; import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.ParticleEffect;
import com.badlogic.gdx.graphics.g2d.ParticleEmitter;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.maps.MapLayer;
import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.MapObjects;
import com.badlogic.gdx.maps.objects.PolygonMapObject;
import com.badlogic.gdx.maps.objects.RectangleMapObject; import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer; import com.badlogic.gdx.maps.tiled.tiles.AnimatedTiledMapTile;
import com.badlogic.gdx.maps.tiled.tiles.StaticTiledMapTile;
import com.badlogic.gdx.math.Intersector;
import com.badlogic.gdx.math.Polygon;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Stage; import com.badlogic.gdx.scenes.scene2d.ui.Skin; import com.badlogic.gdx.utils.viewport.ScreenViewport; import io.github.some_example_name.Control.GameController;
import io.github.some_example_name.View.ui.InventoryUI;
import io.github.some_example_name.model.*;
import io.github.some_example_name.model.Game;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

public class GameView implements Screen , InputProcessor { private MapManager mapManager; private TiledMap map; private OrthogonalTiledMapRenderer mapRenderer; private OrthographicCamera camera; private SpriteBatch batch; private float playerX = 200, playerY = 160; private Rectangle playerRectangle = new Rectangle(200, 160, 20, 20); private float speed = 160; private boolean justTeleported = false; private float teleportCooldown = 1.0f; private GameController gameController; private Stage stage; private Skin skin; private CharacterPlacer placer; private InventoryUI inventoryUI;
    ArrayList <ParticleEffect> rainEffect;

    private final int TILE_SIZE = 16;

    public GameView(GameController gameController, Skin skin, MapManager mapManager) {
        this.gameController = gameController;
        this.mapManager = mapManager;
        this.skin = skin;
        this.stage = new Stage(new ScreenViewport());
        this.batch = new SpriteBatch();
        gameController.setView(this);
        create();
    }

    public void create() {
        map = mapManager.getMap("bigfarm.tmx").getTmxMap();
        mapRenderer = new OrthogonalTiledMapRenderer(map);
        camera = new OrthographicCamera();
        camera.setToOrtho(false, 880, 560);
            int mapWidth = map.getProperties().get("width", Integer.class);
            int mapHeight = map.getProperties().get("height", Integer.class);
            int tileWidth = map.getProperties().get("tilewidth", Integer.class);
            int tileHeight = map.getProperties().get("tileheight", Integer.class);
        TiledMapTileLayer characterLayer = new TiledMapTileLayer(mapWidth, mapHeight, tileWidth, tileHeight);
        characterLayer.setName("craft");

        map.getLayers().add(characterLayer);
//        placeScaledImageAsTile(map, "craft", 10, 11, "soil.png");
//        placeScaledImageAsTile(map, "craft", 9, 10, "soil.png");

        List<MapObject> plantables = App.getCurrentGame()
            .getPlayers()
            .stream()
            .filter(Objects::nonNull)
            .map(Player::getFarm)
            .filter(Objects::nonNull)
            .map(Farm::getAllObjects)
            .filter(Objects::nonNull)
            .flatMap(objs -> objs.iterator().hasNext() ? StreamSupport.stream(objs.spliterator(), false) : Stream.empty())
            .filter(obj -> obj != null && "plantable".equals(obj.getName()))
            .toList();

        IntStream.range(0, mapWidth).forEach(x ->
            IntStream.range(0, mapHeight).forEach(y -> {
                float worldX = x * tileWidth + tileWidth / 2f;
                float worldY = y * tileHeight + tileHeight / 2f;

                plantables.stream()
                    .filter(p -> p instanceof PolygonMapObject)
                    .map(p -> ((PolygonMapObject) p).getPolygon())
                    .filter(polygon -> polygon.contains(worldX, worldY))
                    .findFirst()
                    .ifPresent(p -> placeScaledImageAsTile(map, "craft", x, y, "soil.png"));
            })
        );



        inventoryUI = new InventoryUI(skin);
        stage.addActor(inventoryUI);
//        inventoryUI.pack(); // حتماً ابتدا اندازه‌اش رو فیکس کن

        inventoryUI.setPosition(
            stage.getWidth() / 2f - inventoryUI.getWidth() / 2f,
            stage.getHeight() / 2f - inventoryUI.getHeight() / 2f
        );
//        int tileWidth = map.getProperties().get("tilewidth", Integer.class);
//        int tileHeight = map.getProperties().get("tileheight", Integer.class);
//
//        int mapWidth = map.getProperties().get("width", Integer.class);
//        int mapHeight = map.getProperties().get("height", Integer.class);

        placer = new CharacterPlacer(map);
        rainEffect = loadEffectsForFullMap(map, "Particle Park Rain Cinematic", 4 , 2); // مثلاً "rain" یا "fire"
//        rainEffect.setPosition(100, 200);

        InputMultiplexer multiplexer = new InputMultiplexer(stage, this);
        Gdx.input.setInputProcessor(multiplexer);
    }
    public void placeScaledImageAsTile(TiledMap map, String layerName, int tileX, int tileY, String imagePath) {
        int tileSize = 16; // یا از map.getProperties() بگیر

        // مرحله 1: بارگذاری و کوچک کردن تصویر
        Pixmap pixmap = new Pixmap(Gdx.files.internal(imagePath));
        Pixmap resized = new Pixmap(tileSize, tileSize, pixmap.getFormat());
        resized.drawPixmap(pixmap,
            0, 0, pixmap.getWidth(), pixmap.getHeight(), // from full image
            0, 0, tileSize, tileSize                    // resize to tile size
        );
        Texture texture = new Texture(resized);
        TextureRegion region = new TextureRegion(texture);

        // مرحله 2: تبدیل به تایل
        StaticTiledMapTile tile = new StaticTiledMapTile(region);
        TiledMapTileLayer.Cell cell = new TiledMapTileLayer.Cell();
        cell.setTile(tile);

        // مرحله 3: پیدا کردن لایه (یا ساختن)
        TiledMapTileLayer layer = null;
        MapLayer existingLayer = map.getLayers().get(layerName);
        if (existingLayer instanceof TiledMapTileLayer) {
            layer = (TiledMapTileLayer) existingLayer;
        } else {
            int width = map.getProperties().get("width", Integer.class);
            int height = map.getProperties().get("height", Integer.class);
            layer = new TiledMapTileLayer(width, height, tileSize, tileSize);
            layer.setName(layerName);
            map.getLayers().add(layer);
        }

        // مرحله 4: گذاشتن در مختصات مشخص
        layer.setCell(tileX, tileY, cell);


        // آزادسازی منابع
        pixmap.dispose();
        resized.dispose();
    }

    @Override
    public void render(float delta) {
        AnimatedTiledMapTile.updateAnimationBaseTime();

        int oldTileX = (int) (playerX / TILE_SIZE);
        int oldTileY = (int) (playerY / TILE_SIZE);

        if (teleportCooldown > 0) {
            teleportCooldown -= delta;
            justTeleported = true;
        } else {
            justTeleported = false;
        }

        boolean moved = false;
        CharacterPlacer.Direction direction = null;

        float nextX = playerX;
        float nextY = playerY;

        if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
            nextX -= speed * delta;
            direction = CharacterPlacer.Direction.LEFT;
        } else if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
            nextX += speed * delta;
            direction = CharacterPlacer.Direction.RIGHT;
        } else if (Gdx.input.isKeyPressed(Input.Keys.UP)) {
            nextY += speed * delta;
            direction = CharacterPlacer.Direction.UP;
        } else if (Gdx.input.isKeyPressed(Input.Keys.DOWN)) {
            nextY -= speed * delta;
            direction = CharacterPlacer.Direction.DOWN;
        }

        if (direction != null && !isBlocked(nextX, nextY)) {
            playerX = nextX;
            playerY = nextY;
            moved = true;
        }

        int newTileX = (int) (playerX / TILE_SIZE);
        int newTileY = (int) (playerY / TILE_SIZE);

        if (moved && (newTileX != oldTileX || newTileY != oldTileY)) {
            placer.clearCharacter(oldTileX, oldTileY);
            placer.placeCharacter(newTileX, newTileY, direction);
        } else if (!moved) {
            placer.clearCharacter(newTileX, newTileY);
            placer.dontMove(newTileX, newTileY);
        }

        playerRectangle.setPosition(playerX, playerY);

        // Warp Check
        for (Player player : App.getCurrentGame().getPlayers()) {
            if (!justTeleported && player.getFarm().getAllObjects() != null) {
                for (MapObject object : player.getFarm().getAllObjects()) {
                    if (object instanceof RectangleMapObject) {
                        Rectangle rect = ((RectangleMapObject) object).getRectangle();
                        if (Intersector.overlaps(playerRectangle, rect)) {
                            String newMap = (String) object.getProperties().get("targetMap");
                            Boolean isPrivate = (Boolean) object.getProperties().get("private");
                            if (newMap != null && isPrivate != null) {
                                placer.clearCharacter(newTileX, newTileY);
                                map = isPrivate
                                    ? player.getPersonalMapManager().getMap(newMap).getTmxMap()
                                    : mapManager.getMap(newMap).getTmxMap();
                                mapRenderer.setMap(map);

                                MapObject outObj = map.getLayers().get("object").getObjects().get("out");
                                if (outObj instanceof RectangleMapObject) {
                                    Rectangle outRect = ((RectangleMapObject) outObj).getRectangle();
                                    playerX = outRect.x;
                                    playerY = outRect.y;
                                    playerRectangle.setPosition(playerX, playerY);
                                }
                                placer = new CharacterPlacer(map);
                                teleportCooldown = 1.0f;
                                break;
                            }
                        }
                    }
                }
            }
        }
        for (Player player : App.getCurrentGame().getPlayers()) {
            if (!justTeleported && player.getFarm().getAllObjects() != null) {
                for (MapObject object : player.getFarm().getAllObjects()) {
                    if (object instanceof PolygonMapObject) {
                        if (object.getName().equals("lake")) {
                            Polygon poly = ((PolygonMapObject) object).getPolygon();
                            if (isNearPolygonEdge(poly , playerX , playerY , 16 )) {

                                placer.clearCharacter(newTileX , newTileY);
                                placeScaledImageAsTile(map, "craft", newTileX, newTileY, "soil.png");
                                playerX = 10;
                                playerY = 10;
                            }
                        }

                    }
                }
            }
        }
        if (!justTeleported && map.getLayers().get("object") != null) {
            for (MapObject object : map.getLayers().get("object").getObjects()) {
                if (object instanceof RectangleMapObject) {
                    Rectangle rect = ((RectangleMapObject) object).getRectangle();
                    if (Intersector.overlaps(playerRectangle, rect)) {
                        String newMap = (String) object.getProperties().get("targetMap");
                        if (newMap != null) {
                            map = mapManager.getMap(newMap).getTmxMap();
                            mapRenderer.setMap(map);
                            placer.clearCharacter(newTileX, newTileY);


                            // تنظیم موقعیت بازیکن
                            Optional<MapObject> objectPoint = App.getCurrentGame()
                                .getPlayers()
                                .stream()
                                .map(p -> p.getFarm().getAllObjects().get("out")) // یا getByName بسته به نوع MapObjects
                                .filter(Objects::nonNull)
                                .findFirst();

                            if (objectPoint.isPresent()) {
                                MapObject obj = objectPoint.get();
                                if (obj instanceof RectangleMapObject) {
                                    RectangleMapObject rectObject = (RectangleMapObject) obj;
                                    float x = rectObject.getRectangle().x;
                                    float y = rectObject.getRectangle().y;
                                    playerX = x;
                                    playerY = y;
                                    playerRectangle.setPosition(x, y);
                                }
                            }


                            placer = new CharacterPlacer(map);

                            teleportCooldown = 1.0f;
                            break;
                        }
                    }
                }
            }
        }
        for (Player player : App.getCurrentGame().getPlayers()) {
            if (!justTeleported && player.getFarm().getAllObjects() != null) {
                for (MapObject object : player.getFarm().getAllObjects()) {
                    if (object instanceof PolygonMapObject) {
                        if (object.getName().equals("mineDoor")) {

                            Polygon poly = ((PolygonMapObject) object).getPolygon();
                            if (poly.contains(playerX, playerY)) {
                                System.out.println("hello");
                                String newMap = (String) object.getProperties().get("targetMap");
                                if (newMap != null) {
                                    System.out.println("hi");
                                    map = mapManager.getMap(newMap).getTmxMap();
                                    mapRenderer.setMap(map);

                                    // تنظیم موقعیت بازیکن
                                    MapObject objectPoint = map.getLayers().get("Object").getObjects().get("outMine");
                                    if (objectPoint instanceof RectangleMapObject) {
                                        float x = ((RectangleMapObject) objectPoint).getRectangle().x;
                                        float y = ((RectangleMapObject) objectPoint).getRectangle().y;

                                        playerX = x;
                                        playerY = y;
                                        playerRectangle.setPosition(x, y);
                                    }
                                    placer = new CharacterPlacer(map);

                                    teleportCooldown = 1.0f;
                                    break;
                                }
                            }

                        }
                    }
                }
            }
        }

        if (!justTeleported && map.getLayers().get("object1") != null) {
            for (MapObject object : map.getLayers().get("object1").getObjects()) {
                if (object instanceof RectangleMapObject) {
                    Rectangle rect = ((RectangleMapObject) object).getRectangle();
                    if (Intersector.overlaps(playerRectangle, rect)) {
                        String newMap = (String) object.getProperties().get("targetMap");
                        if (newMap != null) {
                            map = mapManager.getMap(newMap).getTmxMap();
                            mapRenderer.setMap(map);

                            // تنظیم موقعیت بازیکن
                            MapObject objectPoint = map.getLayers().get("object1").getObjects().get("outstore1");
                            if (objectPoint instanceof RectangleMapObject) {
                                float x = ((RectangleMapObject) objectPoint).getRectangle().x;
                                float y = ((RectangleMapObject) objectPoint).getRectangle().y;

                                playerX = x;
                                playerY = y;
                                playerRectangle.setPosition(x, y);
                            }
                            placer = new CharacterPlacer(map);

                            teleportCooldown = 1.0f;
                            break;
                        }
                    }
                }
            }
        }


        // Draw everything
        Gdx.gl.glClearColor(0.15f, 0.15f, 0.2f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        camera.position.set(playerX + TILE_SIZE / 2f, playerY + TILE_SIZE / 2f, 0);
        camera.update();

        mapRenderer.setView(camera);
        mapRenderer.render();
        batch.setProjectionMatrix(mapRenderer.getBatch().getProjectionMatrix());
        batch.begin();
        rainEffect.forEach(effect -> {effect.update(delta);});
        rainEffect.forEach(effect -> {effect.draw(batch);});
        batch.end();


        inventoryUI.update();
        stage.act(delta);
        stage.draw();
    }
    public static boolean isNearPolygonEdge(Polygon polygon, float px, float py, float maxDistance) {
        float[] vertices = polygon.getTransformedVertices();
        Vector2 player = new Vector2(px, py);

        for (int i = 0; i < vertices.length - 2; i += 2) {
            Vector2 p1 = new Vector2(vertices[i], vertices[i + 1]);
            Vector2 p2 = new Vector2(vertices[i + 2], vertices[i + 3]);

            if (Intersector.distanceSegmentPoint(p1, p2, player) <= maxDistance)
                return true;
        }

        Vector2 pLast = new Vector2(vertices[vertices.length - 2], vertices[vertices.length - 1]);
        Vector2 pFirst = new Vector2(vertices[0], vertices[1]);

        return Intersector.distanceSegmentPoint(pLast, pFirst, player) <= maxDistance;
    }
    private boolean isBlocked(float x, float y) {
        int tileX = (int) (x / TILE_SIZE);
        int tileY = (int) (y / TILE_SIZE);

        for (Player player : App.getCurrentGame().getPlayers()) {
            TiledMapTileLayer blockLayer = (TiledMapTileLayer) player.getFarm().getBlockLayer();
            if (blockLayer != null) {
                TiledMapTileLayer.Cell cell = blockLayer.getCell(tileX, tileY);
                if (cell != null) {
                        return true;
                }
            }
            if (!justTeleported && player.getFarm().getAllObjects() != null) {
                for (MapObject object : player.getFarm().getAllObjects()) {
                    if (object instanceof PolygonMapObject) {
                        if (!object.getName().equals("plantable") && !object.getName().equals("mineDoor")) {
                            Polygon poly = ((PolygonMapObject) object).getPolygon();
                            if (poly.contains(x, y)) {
                                return true;
                            }
                        }

                    }
                }
            }
        }

        TiledMapTileLayer blockMapLayer = (TiledMapTileLayer) map.getLayers().get("Buildings5");
        if (blockMapLayer != null) {
            TiledMapTileLayer.Cell cell = blockMapLayer.getCell(tileX, tileY);
            if (cell != null) {
                return true;
            }
        }
        TiledMapTileLayer mineMapLayer = (TiledMapTileLayer) map.getLayers().get("block");
        if (mineMapLayer != null) {
            TiledMapTileLayer.Cell cell = mineMapLayer.getCell(tileX, tileY);
            if (cell != null) {
                return true;
            }
        }


        return false;
    }

    public ArrayList<ParticleEffect> loadEffectsForFullMap(TiledMap map, String effectName, int cols, int rows) {
        ArrayList<ParticleEffect> effects = new ArrayList<>();

        String path = "Particle-Park-master/particles/packs/" + effectName + "/";

        int mapWidth = map.getProperties().get("width", Integer.class);
        int mapHeight = map.getProperties().get("height", Integer.class);
        int tileWidth = map.getProperties().get("tilewidth", Integer.class);
        int tileHeight = map.getProperties().get("tileheight", Integer.class);

        float worldWidth = mapWidth * tileWidth;
        float worldHeight = mapHeight * tileHeight;

        float chunkWidth = worldWidth / cols;
        float chunkHeight = worldHeight / rows;

        for (int col = 0; col < cols; col++) {
            for (int row = 0; row < rows; row++) {
                ParticleEffect effect = new ParticleEffect();
                effect.load(Gdx.files.internal(path + effectName + ".p"), Gdx.files.internal(path));
                effect.start();

                float centerX = col * chunkWidth + chunkWidth / 2f;
                float centerY = row * chunkHeight + chunkHeight / 2f;

                for (ParticleEmitter emitter : effect.getEmitters()) {
                    emitter.getSpawnWidth().setHigh(chunkWidth);
                    emitter.getSpawnHeight().setHigh(chunkHeight);
                    emitter.setPosition(centerX, centerY);
                }

                effects.add(effect);
            }
        }

        return effects;
    }


    @Override
    public void show() {}

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {}

    @Override
    public void dispose() {
        mapManager.disposeAll();
        mapRenderer.dispose();
        batch.dispose();
        if (rainEffect != null) rainEffect.forEach(ParticleEffect::dispose);
    }

    @Override
    public boolean keyDown(int keycode) {
        if (keycode == Input.Keys.ESCAPE) {
            inventoryUI.toggle();
            return true;
        }
        return false;
    }

    @Override
    public boolean keyUp(int keycode) {
        return false;
    }

    @Override
    public boolean keyTyped(char character) {
        return false;
    }

    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        return false;
    }

    @Override
    public boolean touchUp(int screenX, int screenY, int pointer, int button) {
        return false;
    }

    @Override
    public boolean touchCancelled(int screenX, int screenY, int pointer, int button) {
        return false;
    }

    @Override
    public boolean touchDragged(int screenX, int screenY, int pointer) {
        return false;
    }

    @Override
    public boolean mouseMoved(int screenX, int screenY) {
        return false;
    }

    @Override
    public boolean scrolled(float amountX, float amountY) {
        return false;
    }
}
