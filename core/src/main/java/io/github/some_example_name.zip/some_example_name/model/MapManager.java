package io.github.some_example_name.model;

import com.badlogic.gdx.maps.MapLayer;
import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.objects.*;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer.Cell;
import com.badlogic.gdx.maps.tiled.objects.TiledMapTileMapObject;
import com.badlogic.gdx.math.*;

import java.util.HashMap;
import java.util.List;

public class MapManager {
    private final TmxMapLoader loader = new TmxMapLoader();
    private final HashMap<String, Map> mapCache = new HashMap<>();
//    private boolean merged = false;

    public Map getMap(String fileName) {
        if (mapCache.containsKey(fileName)) {
            return mapCache.get(fileName);
        }

        TiledMap tiledMap = loader.load(fileName);
//
//        if (fileName.equals("bigmap.tmx") && !merged) {
//            TiledMap smallMap = loader.load("untitled.tmx");
//            mergeMapIntoBigMap(map, smallMap);
//            merged = true;
//        }
        Map map = new Map();
        map.setTmxMap(tiledMap);

        mapCache.put(fileName, map);
        return map;
    }
    public void createMap(List<String> selectedMaps , List<Player> players) {

        TiledMap bigMapTile = loader.load("bigfarm.tmx");

        int tileHeight = bigMapTile.getProperties().get("tileheight", Integer.class);
        int tileWidth = bigMapTile.getProperties().get("tilewidth", Integer.class);
        TiledMap smallMap = loader.load(selectedMaps.get(0));
        int offsetY = (bigMapTile.getProperties().get("height", Integer.class) -
            smallMap.getProperties().get("height", Integer.class)) * tileHeight;
        int offsetX = 0;
        mergeMapIntoBigMap(bigMapTile, smallMap , players.get(0), offsetX, offsetY);
        Map map0 = new Map();
        map0.setTmxMap(smallMap);
        mapCache.put(selectedMaps.get(0), map0);
        smallMap = loader.load(selectedMaps.get(1));
        offsetX = (bigMapTile.getProperties().get("width", Integer.class) -smallMap.getProperties().get("width", Integer.class)) * tileWidth;
        mergeMapIntoBigMap(bigMapTile, smallMap , players.get(1) , offsetX, offsetY);
        Map map1 = new Map();
        map1.setTmxMap(smallMap);
        mapCache.put(selectedMaps.get(1), map1);
        if (selectedMaps.size() > 2) {
            smallMap = loader.load(selectedMaps.get(1));
            offsetX = 0;
            offsetY = 0;
            mergeMapIntoBigMap(bigMapTile, smallMap , players.get(2) , offsetX, offsetY);
            Map map2 = new Map();
            map2.setTmxMap(smallMap);
            mapCache.put(selectedMaps.get(2), map2);
        }
        if (selectedMaps.size() > 3) {
            smallMap = loader.load(selectedMaps.get(2));
            offsetX = (bigMapTile.getProperties().get("width", Integer.class) -smallMap.getProperties().get("width", Integer.class)) * tileWidth;
            mergeMapIntoBigMap(bigMapTile, smallMap , players.get(3) ,offsetX, offsetY);
            Map map3 = new Map();
            map3.setTmxMap(smallMap);
            mapCache.put(selectedMaps.get(3), map3);
        }
        Map bigMap = new Map();
        bigMap.setTmxMap(bigMapTile);
        mapCache.put("bigfarm.tmx", bigMap);
    }

    private void mergeMapIntoBigMap(TiledMap bigMap, TiledMap smallMap , Player player , int offsetX , int offsetY) {
        int tileHeight = bigMap.getProperties().get("tileheight", Integer.class);
        int tileWidth = bigMap.getProperties().get("tilewidth", Integer.class);


        // پیدا کردن آخرین لایه‌ی تایل‌دار
        TiledMapTileLayer targetLayer = null;
        for (int i = bigMap.getLayers().getCount() - 1; i >= 0; i--) {
            if (bigMap.getLayers().get(i) instanceof TiledMapTileLayer) {
                targetLayer = (TiledMapTileLayer) bigMap.getLayers().get(i);
                break;
            }
        }
        if (targetLayer == null) return;


        // کپی‌کردن تایل‌های smallMap در موقعیت مناسب به targetLayer
        cloneSmallMap(bigMap , smallMap , player , offsetY , tileHeight , offsetX , tileWidth );
    }
    private void cloneSmallMap(TiledMap bigMap, TiledMap smallMap , Player player, int offsetY , int tileHeight , int offsetX , int tileWidth ) {
        Farm farm = new Farm();
        for (MapLayer layer : smallMap.getLayers()) {
            if (layer instanceof TiledMapTileLayer) {
                TiledMapTileLayer sourceLayer = (TiledMapTileLayer) layer;

                // ساخت لایه جدید با همان تنظیمات
                TiledMapTileLayer newLayer = new TiledMapTileLayer(
                    sourceLayer.getWidth() + (offsetX / tileWidth),
                    sourceLayer.getHeight() + (offsetY / tileHeight),
                    sourceLayer.getTileWidth(),
                    sourceLayer.getTileHeight()
                );
                newLayer.setName(sourceLayer.getName());

                // کپی کردن سلول‌ها با offset
                for (int x = 0; x < sourceLayer.getWidth(); x++) {
                    for (int y = 0; y < sourceLayer.getHeight(); y++) {
                        Cell cell = sourceLayer.getCell(x, y);
                        if (cell != null && cell.getTile() != null) {
                            Cell newCell = new Cell();
                            newCell.setTile(cell.getTile());
                            newLayer.setCell(x + (offsetX / tileWidth), y + (offsetY / tileHeight), newCell);
                        }
                    }
                }
                if (newLayer.getName().equals("Buildings3")) {
                    farm.setBlockLayer(newLayer);
                }

                bigMap.getLayers().add(newLayer);
            } else {
                // object layers as before
                MapLayer newLayer = new MapLayer();
                newLayer.setName(layer.getName());

                for (MapObject obj : layer.getObjects()) {
                    MapObject copy = cloneMapObject(obj, offsetX ,offsetY );
                    newLayer.getObjects().add(copy);
                }
               farm.setObjectLayer(newLayer);


                bigMap.getLayers().add(newLayer);
            }
        }
        player.setFarm(farm);
    }

    private MapObject cloneMapObject(MapObject original, float offsetX, float offsetY) {
        MapObject copy;

        if (original instanceof RectangleMapObject) {
            Rectangle rect = ((RectangleMapObject) original).getRectangle();
            Rectangle newRect = new Rectangle(rect);
            newRect.x += offsetX;
            newRect.y += offsetY;
            copy = new RectangleMapObject(newRect.x, newRect.y, newRect.width, newRect.height);
        } else if (original instanceof EllipseMapObject) {
            Ellipse ellipse = ((EllipseMapObject) original).getEllipse();
            Ellipse newEllipse = new Ellipse(ellipse);
            newEllipse.x += offsetX;
            newEllipse.y += offsetY;
            copy = new EllipseMapObject(newEllipse.x , newEllipse.y, newEllipse.width, newEllipse.height);
        } else if (original instanceof CircleMapObject) {
            Circle circle = ((CircleMapObject) original).getCircle();
            Circle newCircle = new Circle(circle);
            newCircle.x += offsetX;
            newCircle.y += offsetY;
            copy = new CircleMapObject(newCircle.x , newCircle.y , newCircle.radius );
        } else if (original instanceof PolylineMapObject) {
            Polyline polyline = ((PolylineMapObject) original).getPolyline();
            float[] oldVertices = polyline.getTransformedVertices(); // یا getVertices() بسته به نیاز
            float[] newVertices = new float[oldVertices.length];
            for (int i = 0; i < oldVertices.length; i += 2) {
                newVertices[i] = oldVertices[i] + offsetX;
                newVertices[i + 1] = oldVertices[i + 1] + offsetY;
            }
            Polyline newPolyline = new Polyline(newVertices);
            copy = new PolylineMapObject(newPolyline);
        } else if (original instanceof PolygonMapObject) {
            Polygon polygon = ((PolygonMapObject) original).getPolygon();
            float[] oldVertices = polygon.getVertices(); // vertices نسبت به position هستن
            float[] newVertices = new float[oldVertices.length];
            System.arraycopy(oldVertices, 0, newVertices, 0, oldVertices.length);

            Polygon newPolygon = new Polygon(newVertices);
            newPolygon.setPosition(polygon.getX() + offsetX, polygon.getY() + offsetY);
            newPolygon.setRotation(polygon.getRotation());
            newPolygon.setScale(polygon.getScaleX(), polygon.getScaleY());

            copy = new PolygonMapObject(newPolygon);
        }
//        else if (original instanceof TiledMapTileMapObject) {
//            TiledMapTileMapObject tileObj = (TiledMapTileMapObject) original;
//            copy = new TiledMapTileMapObject(tileObj.getTile());
//            ((TiledMapTileMapObject) copy).setX(tileObj.getX() + offsetX);
//            ((TiledMapTileMapObject) copy).setY(tileObj.getY() + offsetY);
//            ((TiledMapTileMapObject) copy).setRotation(tileObj.getRotation());
//            ((TiledMapTileMapObject) copy).setScale(tileObj.getScaleX(), tileObj.getScaleY());
//            ((TiledMapTileMapObject) copy).setFlipHorizontally(tileObj.isFlipHorizontally());
//            ((TiledMapTileMapObject) copy).setFlipVertically(tileObj.isFlipVertically());
//        }
        else {
            // Default fallback: copy properties and offset x/y if available
            copy = new MapObject();
            Float y = original.getProperties().get("y", Float.class);
            Float x = original.getProperties().get("x", Float.class);
            if (y != null) {
                copy.getProperties().put("y", y + offsetY);
            }
            if (x != null) {
                copy.getProperties().put("x", x + offsetX);
            }
        }

        // Copy name and all properties
        copy.setName(original.getName());
        copy.getProperties().putAll(original.getProperties());

        return copy;
    }

    public void disposeAll() {
        for (Map map : mapCache.values()) {
            map.getTmxMap().dispose();
        }
        mapCache.clear();
    }
}
