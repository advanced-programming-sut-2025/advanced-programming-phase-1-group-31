package io.github.some_example_name.model.enums.general;

public enum Weather {
    Sunny,
    Rainy,
    Stormy,
    Snowy
}
