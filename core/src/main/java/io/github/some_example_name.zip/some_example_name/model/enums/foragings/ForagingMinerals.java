package io.github.some_example_name.model.enums.foragings;


import io.github.some_example_name.model.materials.MaterialType;

import java.util.Random;

public enum ForagingMinerals implements MaterialType {
    Quartz("Quartz", "A clear crystal commonly found in caves and mines.", 25),
    EarthCrystal("Earth Crystal", "A resinous substance found near the surface.", 50),
    FrozenTear("Frozen Tear", "A crystal fabled to be the frozen tears of a yeti.", 75),
    FireQuartz("Fire Quartz", "A glowing red crystal commonly found near hot lava.", 100),
    Emerald("Emerald", "A precious stone with a brilliant green color.", 250),
    Aquamarine("Aquamarine", "A shimmery blue-green gem.", 180),
    Ruby("Ruby", "A precious stone that is sought after for its rich color and beautiful luster.",
            250),
    Amethyst("Amethyst", "A purple variant of quartz.", 100),
    Topaz("Topaz", "Fairly common but still prized for its beauty.", 80),
    Jade("Jade", "A pale green ornamental stone.", 200),
    Diamond("Diamond", "A rare and valuable gem.", 750),
    PrismaticShard("Prismatic Shard", "A very rare and powerful substance with unknown origins.",
            2000),
    WOOD("Wood", "It is taken from a tree.", 4),
    STONE("Stone", "Common Stone", 2),
    COPPER_ORE("Copper Ore", "A common ore that can be smelted into bars.", 5),
    IRON_ORE("Iron Ore", "A fairly common ore that can be smelted into bars.", 10),
    GOLD_ORE("Gold Ore", "A precious ore that can be smelted into bars.", 25),
    IRIDIUM_ORE("Iridium Ore", "An exotic ore with many curious properties. Can be smelted into bars.",
            100),
    FIBER("Fiber", "just fiber", 10);


    private final String displayName;
    private final String description;
    private final int sellPrice;

    ForagingMinerals(String displayName, String description, int sellPrice) {
        this.displayName = displayName;
        this.description = description;
        this.sellPrice = sellPrice;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDescription() {
        return description;
    }

    public int getSellPrice() {
        return sellPrice;
    }

    private static final Random RANDOM = new Random();
    @Override
    public String toString() {
        return displayName;
    }

    public static ForagingMinerals getRandom() {
        ForagingMinerals[] values = ForagingMinerals.values();
        return values[RANDOM.nextInt(values.length)];
    }
}
