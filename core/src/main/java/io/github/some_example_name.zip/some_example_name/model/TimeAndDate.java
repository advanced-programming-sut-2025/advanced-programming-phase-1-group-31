package io.github.some_example_name.model;



import io.github.some_example_name.model.enums.crafting.Industrials;
import io.github.some_example_name.model.enums.foragings.ForagingCrops;
import io.github.some_example_name.model.enums.foragings.ForagingMinerals;
import io.github.some_example_name.model.enums.foragings.ForagingSeeds;
import io.github.some_example_name.model.enums.general.Seasons;
import io.github.some_example_name.model.enums.general.TileType;
import io.github.some_example_name.model.enums.general.Weather;
import io.github.some_example_name.model.materials.*;
import io.github.some_example_name.model.materials.Foraging.ForagingCrop;
import io.github.some_example_name.model.materials.Foraging.ForagingMineral;
import io.github.some_example_name.model.materials.Foraging.ForagingSeed;
import io.github.some_example_name.model.materials.Foraging.ForagingTree;

import java.awt.*;
import java.time.DayOfWeek;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

//cheat code for changing weather must be added.

public class TimeAndDate {
    private final Random random = new Random();
    private int hour = 9;
    private int day = 1;
    private Seasons season = Seasons.Spring;
    private Weather weather = Weather.Sunny;
    private Weather tomorrowWeather = Weather.Sunny;
    private DayOfWeek dayOfWeek = DayOfWeek.SATURDAY;

    public void addHour(int addHour) {
        // this algorithm to keep hour between 9-22
        hour -= 8;
        hour += addHour;
        if (hour > 14) {
            int countOfDay = hour / 14;
            hour = (hour - 1) % 14 + 1;
            addDay(countOfDay);
        }
        hour += 8;
    }

    public void addDay(int addDay) {
        day += addDay;
        int countOfSeason = (day - 1) / 28;
        day = (day - 1) % 28 + 1;
        for (int i = 0; i < countOfSeason; i++) {
            changeSeason();
        }
        int countOfWeek = addDay % 7;
        for (int i = 0; i < countOfWeek; i++) {
            changeWeek();
        }

        weather = tomorrowWeather;

        if (season == Seasons.Winter) {
            tomorrowWeather = (random.nextInt(2) == 0) ? Weather.Sunny : Weather.Snowy;
        } else {
            tomorrowWeather = switch (random.nextInt(3)) {
                case 1 -> Weather.Rainy;
                case 2 -> Weather.Stormy;
                default -> Weather.Sunny;
            };
        }
        for (int i = 0; i < addDay; i++) {
            if (weather.equals(Weather.Stormy)) thunder();
            App.getCurrentGame().getMainMap();
            updateAnimalOutdoorsStatus();
            changeForagingAndCrops();
            App.getCurrentGame().getPlayers().forEach(player -> player.getEnergy().onNewDay());
            for (Player player : App.getCurrentGame().getPlayers()){
                App.getCurrentGame().getShoppingBin().addMoney(player);
            }
        }
    }

    private void changeWeek() {
        switch (dayOfWeek) {
            case SATURDAY -> dayOfWeek = DayOfWeek.SUNDAY;
            case SUNDAY -> dayOfWeek = DayOfWeek.MONDAY;
            case MONDAY -> dayOfWeek = DayOfWeek.TUESDAY;
            case TUESDAY -> dayOfWeek = DayOfWeek.WEDNESDAY;
            case WEDNESDAY -> dayOfWeek = DayOfWeek.THURSDAY;
            case THURSDAY -> dayOfWeek = DayOfWeek.FRIDAY;
            case FRIDAY -> dayOfWeek = DayOfWeek.SATURDAY;
        }
    }

    private void changeSeason() {
        switch (season) {
            case Spring -> season = Seasons.Summer;
            case Summer -> season = Seasons.Fall;
            case Fall -> season = Seasons.Winter;
            case Winter -> season = Seasons.Spring;
        }
    }

    public void setTomorrowWeather(Weather tomorrowWeather) {
        this.tomorrowWeather = tomorrowWeather;
    }

    public Weather getTomorrowWeather() {
        return tomorrowWeather;
    }

    public int getHour() {
        return hour;
    }

    public int getDay() {
        return day;
    }

    public Seasons getSeason() {
        return season;
    }

    public Weather getWeather() {
        return weather;
    }

    public DayOfWeek getDayOfWeek() {
        return dayOfWeek;
    }

    private void thunder() {
        for (Player player : App.getCurrentGame().getPlayers()) {
            for (int i = 0; i < 3; i++) {
                int x = random.nextInt(55);
                int y = random.nextInt(35);
                thunder(new Point(x, y), player.getFarm().getMainMap());
            }
        }

    }

    public void thunder(Point point, Tile[][] farmMap) {
        Tile tile = farmMap[point.x][point.y];
        if (tile.getMaterial() instanceof Tree || tile.getMaterial() instanceof ForagingTree) {
            tile.setType(TileType.Craftable);
            tile.setMaterial(new Industrial(Industrials.COAL));
        }

    }

    public void changeForagingAndCrops() {
        Map map = App.getCurrentGame().getMainMap();
        Tile[][] tiles = map.getMainMap();

        for (Tile[] value : tiles) {
            for (Tile tile : value) {
                if (tile.getType() == TileType.SEED && tile.getMaterial() instanceof Seed seed) {

                    if (seed.getDaysWithoutWater() >= 2) {
                        tile.setType(TileType.EMPTY);
                        tile.setMaterial(null);
                    } else if (seed.isFullyGrown()) {
                        if (seed.getCorrespondingCrop() != null) {
                            tile.setType(TileType.CROPS);
                            tile.setMaterial(new Crop(seed.getCorrespondingCrop()));
                        } else if (seed.getCorrespondingTrees() != null) {
                            tile.setType(TileType.TREE);
                            tile.setMaterial(new Tree(seed.getCorrespondingTrees()));
                        }
                    }
                    if (seed.getDaysWithoutWater() == 0) {
                        seed.grow();
                    }
                    seed.setDaysWithoutWater(seed.getDaysWithoutWater() + 1);

                } else if (tile.getType() == TileType.CROPS && tile.getMaterial() instanceof Crop crop) {
                    if (crop.getDaysWithoutWater() >= 2) {
                        tile.setType(TileType.EMPTY);
                        tile.setMaterial(null);
                    }
                    crop.nextDay();
                    crop.setDaysWithoutWater(crop.getDaysWithoutWater() + 1);
                } else if (tile.getType() == TileType.TREE && tile.getMaterial() instanceof Tree tree) {
                    if (tree.getDaysWithoutWater() >= 2) {
                        tile.setType(TileType.EMPTY);
                        tile.setMaterial(null);
                    }
                    tree.nextDay();
                    tree.setDaysWithoutWater(tree.getDaysWithoutWater() + 1);
                }
            }
        }

        for (int i = 0; i < tiles.length; i++) {
            for (int j = 0; j < tiles[i].length; j++) {
                Tile tile = tiles[i][j];
                 if (tile.getType()==TileType.QUARRY) {

                 }
                double chance = ThreadLocalRandom.current().nextDouble();
                int finalI = i;
                int finalJ = j;
                if (chance <= 0.01 &&tile.getType()==TileType.QUARRY) {
                     ForagingMinerals mineral = ForagingMinerals.getRandom();
                            tile.setType(TileType.FORAGING_MINERAL);
                            tile.setMaterial(new ForagingMineral(mineral));
                 }
                if (chance <= 0.005 && (tile.getType() == TileType.EMPTY || tile.getType() == TileType.PLANTING_SOIL)
                        && App.getCurrentGame().getPlayers().stream()
                                .noneMatch(p -> (p.getPlace().x == finalI || p.getPlace().y == finalJ))) {
                    Seasons season = App.getCurrentGame().getTimeAndDate().getSeason();

                    int type = ThreadLocalRandom.current().nextInt(3);
                    switch (type) {
                        case 0 -> {
                            if (tile.getType() == TileType.EMPTY && tile.getMaterial() == null) {
                                ForagingCrops crop = ForagingCrops.getRandomBySeason(season);
                                tile.setType(TileType.FORAGING_CROPS);
                                tile.setMaterial(new ForagingCrop(crop));
                            }

                        }
                        case 1 -> {
                            if (tile.getType() == TileType.PLANTING_SOIL && tile.getMaterial() == null) {
                                ForagingSeeds seed = ForagingSeeds.getRandomBySeason(season);
                                tile.setType(TileType.SEED);
                                tile.setMaterial(new ForagingSeed(seed));
                            }
                        }
                        case 2 -> {
                            // ForagingMinerals mineral = ForagingMinerals.getRandom();
                            // tile.setType(TileType.FORAGING_MINERAL);
                            // tile.setMaterial(new ForagingMineral(mineral));
                        }
                    }
                }
            }
        }
    }
    public static void updateAnimalOutdoorsStatus() {
        for (Coop coop : App.getCurrentGame().getPlayers().stream().flatMap(player -> player.getFarm().getCoops().stream()).toList()) {
            for (Animal animal : coop.getAnimals()) {
                animal.generateProduct();
                animal.getAnimalFriendship().endDay();
            }
        }

        for (Barn barn : App.getCurrentGame().getPlayers().stream().flatMap(player -> player.getFarm().getBarns().stream()).toList()) {
            for (Animal animal : barn.getAnimals()) {
                animal.generateProduct();
                animal.getAnimalFriendship().endDay();
            }
        }
    }

}
